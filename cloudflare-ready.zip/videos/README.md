# MAISON DORÉE — Cinematic Video Asset Directory

Place your compressed H.264 `.mp4` (or `.webm`) culinary video files in this directory using the exact filenames below.
Once added, the HTML5 video elements and GSAP ScrollTrigger scroll-scrubbing engine will automatically load and scrub them.

| Slot ID | Expected File Path | Role |
| :--- | :--- | :--- |
| `hero` | `/public/videos/hero-experience.mp4` | Full-screen Hero atmospheric culinary film |
| `coffee` | `/public/videos/coffee-extraction.mp4` | Scroll-controlled espresso extraction sequence |
| `burger` | `/public/videos/wagyu-burger.mp4` | Scroll-controlled Wagyu sear & brioche assembly |
| `pizza` | `/public/videos/woodfired-pizza.mp4` | Scroll-controlled wood-fired oven & burrata finish |
| `pasta` | `/public/videos/truffle-pasta.mp4` | Scroll-controlled fresh pasta & truffle shaving |
| `dessert` | `/public/videos/chocolate-patisserie.mp4` | Scroll-controlled ganache glaze & gold leaf placement |
| `beverages` | `/public/videos/smoked-cocktails.mp4` | Scroll-controlled smoked amber cocktail pour |
| `transition` | `/public/videos/culinary-transition.mp4` | Inter-chapter culinary flame & steam transition |

Note: Until files are added here, the website displays high-resolution commercial photography posters with a clearly identified video asset placeholder and allows attaching local `.mp4` files directly in-browser for immediate scroll-scrub preview.
