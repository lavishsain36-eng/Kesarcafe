export type VideoSlotId =
  | 'hero'
  | 'heroPartTwo'
  | 'coffee'
  | 'burger'
  | 'pizza'
  | 'pasta'
  | 'dessert'
  | 'beverages'
  | 'transition';

export interface VideoAssetSpec {
  id: VideoSlotId;
  label: string;
  description: string;
  src: string;
  posterImage: string;
  expectedFilename: string;
  playbackMode: 'autoplay-loop' | 'scroll-scrub' | 'sequential';
}

export const HERO_VIDEO_ONE_PATH =
  '/assets/aistudio/From_Klickpin.com-_92_Stunning_Walking_Challenge_Ideas-pin-id-1092263715916408624_110d7fed.mp4';

export const HERO_VIDEO_TWO_PATH =
  '/assets/aistudio/From_Klickpin.com-_Refresh_this_guide_to_easy_handmade_card_ideas_that_make_everything_look_instantly_polished_for_a_stylish_result_that_still_fee_7ea78769.mp4';

export const VIDEO_ASSET_REGISTRY: Record<VideoSlotId, VideoAssetSpec> = {
  hero: {
    id: 'hero',
    label: 'Hero Film — Part I',
    description: 'Primary full-play hero showcase reel (plays first in full)',
    src: HERO_VIDEO_ONE_PATH,
    posterImage: '/src/assets/images/hero_luxury_restaurant_1795258603293.jpg',
    expectedFilename:
      'public/assets/aistudio/From_Klickpin.com-_92_Stunning_Walking_Challenge_Ideas-pin-id-1092263715916408624_110d7fed.mp4',
    playbackMode: 'sequential',
  },
  heroPartTwo: {
    id: 'heroPartTwo',
    label: 'Hero Film — Part II',
    description: 'Secondary hero showcase reel (plays automatically after Part I)',
    src: HERO_VIDEO_TWO_PATH,
    posterImage: '/src/assets/images/interior_dining_room_1795258604262.jpg',
    expectedFilename:
      'public/assets/aistudio/From_Klickpin.com-_Refresh_this_guide_to_easy_handmade_card_ideas_that_make_everything_look_instantly_polished_for_a_stylish_result_that_still_fee_7ea78769.mp4',
    playbackMode: 'sequential',
  },
  coffee: {
    id: 'coffee',
    label: 'Kulhad Chai & Kaapi Film',
    description: 'Brass filter pour & spiced saffron cardamom brew',
    src: '/videos/coffee-extraction.mp4',
    posterImage: '/src/assets/images/food_coffee_espresso_1795258603193.jpg',
    expectedFilename: 'public/videos/coffee-extraction.mp4',
    playbackMode: 'scroll-scrub',
  },
  burger: {
    id: 'burger',
    label: 'Kathi Rolls & Bombay Grill Film',
    description: 'Charred paratha rolls & spiced grilled club toasties',
    src: '/videos/wagyu-burger.mp4',
    posterImage: '/src/assets/images/food_wagyu_burger_1795258603457.jpg',
    expectedFilename: 'public/videos/wagyu-burger.mp4',
    playbackMode: 'scroll-scrub',
  },
  pizza: {
    id: 'pizza',
    label: 'Kulcha & Tandoori Hearth Film',
    description: 'Blistered heritage wheat dough & spiced makhani finish',
    src: '/videos/woodfired-pizza.mp4',
    posterImage: '/src/assets/images/food_artisan_pizza_1795258602104.jpg',
    expectedFilename: 'public/videos/woodfired-pizza.mp4',
    playbackMode: 'scroll-scrub',
  },
  pasta: {
    id: 'pasta',
    label: 'Indian Spice Bowls Film',
    description: 'Slow-simmered saffron makhani & hand-pounded masalas',
    src: '/videos/truffle-pasta.mp4',
    posterImage: '/src/assets/images/food_truffle_pasta_1795258604261.jpg',
    expectedFilename: 'public/videos/truffle-pasta.mp4',
    playbackMode: 'scroll-scrub',
  },
  dessert: {
    id: 'dessert',
    label: 'Saffron Waffles & Mithai Film',
    description: 'Crisp Belgian waffles with rabri, cardamom & dark cacao',
    src: '/videos/chocolate-patisserie.mp4',
    posterImage: '/src/assets/images/food_chocolate_dessert_1795258603196.jpg',
    expectedFilename: 'public/videos/chocolate-patisserie.mp4',
    playbackMode: 'scroll-scrub',
  },
  beverages: {
    id: 'beverages',
    label: 'Smoked Sharbat & Shakes Film',
    description: 'Rose badam, kokum & sandalwood-smoked cold brews',
    src: '/videos/smoked-cocktails.mp4',
    posterImage: '/src/assets/images/food_smoked_beverage_1795258603980.jpg',
    expectedFilename: 'public/videos/smoked-cocktails.mp4',
    playbackMode: 'scroll-scrub',
  },
  transition: {
    id: 'transition',
    label: 'Kitchen Transition Reel',
    description: 'Tandoor flame & spice tempering sequence',
    src: HERO_VIDEO_TWO_PATH,
    posterImage: '/src/assets/images/signature_seared_steak_1795258602968.jpg',
    expectedFilename:
      'public/assets/aistudio/From_Klickpin.com-_Refresh_this_guide_to_easy_handmade_card_ideas_that_make_everything_look_instantly_polished_for_a_stylish_result_that_still_fee_7ea78769.mp4',
    playbackMode: 'scroll-scrub',
  },
};

export const VIDEO_SLOT_LIST: VideoAssetSpec[] = Object.values(VIDEO_ASSET_REGISTRY);
